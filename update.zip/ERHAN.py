import sys
import threading
import time
import requests
import zipfile
import os
from PyQt6.QtWidgets import (
    QApplication, QWidget, QPushButton, QLabel, QTextEdit, QVBoxLayout, QMessageBox
)
from PyQt6.QtGui import QFont
from PyQt6.QtCore import Qt

CURRENT_VERSION = "1.0.1"  # Burayı güncel tut
VERSION_URL = "https://raw.githubusercontent.com/yamann0101/sur-bey-updates/main/version.txt"
ZIP_URL = "https://github.com/yamann0101/sur-bey-updates/raw/main/update.zip"
ZIP_NAME = "update.zip"


class BotWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SUR`BEY - Güncelleme & Bot")
        self.setGeometry(400, 100, 700, 500)
        self.setStyleSheet("background-color: black; color: white;")

        layout = QVBoxLayout()
        self.setLayout(layout)

        # Başlık
        self.label = QLabel("SUR`BEY")
        self.label.setFont(QFont("Arial", 48, QFont.Weight.Bold))
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label.setStyleSheet("color: orange;")
        layout.addWidget(self.label)

        # Log Paneli
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setStyleSheet("background-color: #222; color: #0f0; font-family: Consolas;")
        layout.addWidget(self.log_output)

        # Çalıştır / Durdur Butonu
        self.toggle_button = QPushButton("Çalıştır")
        self.toggle_button.setStyleSheet("""
            QPushButton {
                background-color: orange;
                color: black;
                font-size: 18px;
                border-radius: 10px;
                padding: 10px;
                margin-top: 10px;
            }
            QPushButton:hover {
                background-color: #ffaa00;
            }
        """)
        self.toggle_button.setFixedWidth(150)
        self.toggle_button.clicked.connect(self.toggle_bot)
        layout.addWidget(self.toggle_button, alignment=Qt.AlignmentFlag.AlignHCenter)

        # Durumlar
        self.running = False
        self.bot_thread = None

        # Başlangıçta güncelleme kontrolü
        threading.Thread(target=self.check_for_updates, daemon=True).start()

    def log(self, message):
        print(message)
        self.log_output.append(message)
        scrollbar = self.log_output.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def toggle_bot(self):
        if not self.running:
            self.running = True
            self.toggle_button.setText("Durdur")
            self.log("[BOT] Başlatıldı.")
            self.bot_thread = threading.Thread(target=self.loop_bot, daemon=True)
            self.bot_thread.start()
        else:
            self.running = False
            self.toggle_button.setText("Çalıştır")
            self.log("[BOT] Durduruldu.")

    def loop_bot(self):
        while self.running:
            self.log("[BOT] İşlem yapılıyor...")
            time.sleep(2)

    def check_for_updates(self):
        try:
            self.log("[GÜNCELLEME] Sürüm kontrol ediliyor...")
            response = requests.get(VERSION_URL, timeout=5)
            latest_version = response.text.strip()

            if latest_version != CURRENT_VERSION:
                self.log(f"[GÜNCELLEME] Yeni sürüm bulundu: {latest_version}")
                self.download_and_extract_update()
                self.show_update_message()
            else:
                self.log("[GÜNCELLEME] Uygulama güncel.")
        except Exception as e:
            self.log(f"[HATA] Güncelleme kontrolü başarısız: {e}")

    def download_and_extract_update(self):
        try:
            self.log("[GÜNCELLEME] update.zip indiriliyor...")
            r = requests.get(ZIP_URL, stream=True)
            with open(ZIP_NAME, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
            self.log("[GÜNCELLEME] update.zip indirildi.")

            self.log("[GÜNCELLEME] Zip çıkarılıyor...")
            with zipfile.ZipFile(ZIP_NAME, 'r') as zip_ref:
                zip_ref.extractall(os.getcwd())
            self.log("[GÜNCELLEME] Güncelleme başarıyla çıkarıldı.")
            os.remove(ZIP_NAME)
        except Exception as e:
            self.log(f"[HATA] Güncelleme indirilemedi: {e}")

    def show_update_message(self):
        self.log("[GÜNCELLEME] Lütfen uygulamayı yeniden başlatın.")
        QMessageBox.information(self, "Güncelleme", "Yeni sürüm yüklendi.\nUygulamayı yeniden başlatın.")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = BotWindow()
    window.show()
    sys.exit(app.exec())
