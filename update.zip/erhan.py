import sys
import requests
import zipfile
import io
import os
from packaging import version
from PyQt6.QtWidgets import (
    QApplication, QWidget, QPushButton, QLabel, QTextEdit, QVBoxLayout, QMessageBox
)
from PyQt6.QtGui import QFont
from PyQt6.QtCore import Qt

MEVCUT_SURUM = "1.0.0"  # Şu anki kurulu sürüm
VERSION_URL = "https://raw.githubusercontent.com/yamann0101/sur-bey-updates/main/version.txt"
UPDATE_ZIP_URL = "https://github.com/yamann0101/sur-bey-updates/raw/main/update.zip"

class AutoUpdateWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SUR'BEY Otomatik Güncelleme")
        self.setGeometry(400, 100, 700, 500)
        self.setStyleSheet("background-color: black; color: white;")

        layout = QVBoxLayout()
        self.setLayout(layout)

        self.label = QLabel("SUR'BEY")
        self.label.setFont(QFont("Arial", 48, QFont.Weight.Bold))
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label.setStyleSheet("color: orange;")
        layout.addWidget(self.label)

        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setStyleSheet("background-color: #222; color: #0f0; font-family: Consolas;")
        layout.addWidget(self.log_output)

        self.update_button = QPushButton("Güncellemeleri Kontrol Et ve Yükle")
        self.update_button.setStyleSheet("""
            QPushButton {
                background-color: orange;
                color: black;
                font-size: 18px;
                border-radius: 10px;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #ffaa00;
            }
        """)
        self.update_button.clicked.connect(self.check_and_update)
        layout.addWidget(self.update_button)

    def log(self, text):
        self.log_output.append(text)

    def check_and_update(self):
        try:
            self.log("Güncelleme kontrol ediliyor...")
            response = requests.get(VERSION_URL, timeout=5)
            if response.status_code != 200:
                self.log("version.txt dosyasına ulaşılamadı!")
                return

            latest_version = response.text.strip()
            self.log(f"Son sürüm: {latest_version}")
            self.log(f"Mevcut sürüm: {MEVCUT_SURUM}")

            if version.parse(latest_version) > version.parse(MEVCUT_SURUM):
                self.log("Yeni sürüm bulundu. İndiriliyor...")
                self.download_and_extract_update()
            else:
                self.log("Uygulama güncel.")
                QMessageBox.information(self, "Güncel", "Uygulamanız zaten güncel.")
        except Exception as e:
            self.log(f"Hata: {e}")

    def download_and_extract_update(self):
        try:
            response = requests.get(UPDATE_ZIP_URL, timeout=30)
            if response.status_code != 200:
                self.log("Güncelleme dosyası indirilemedi!")
                return

            self.log("Güncelleme dosyası indirildi. Dosyalar açılıyor...")
            with zipfile.ZipFile(io.BytesIO(response.content)) as zip_file:
                zip_file.extractall(".")  # Çalışma dizinine açılıyor
            self.log("Güncelleme tamamlandı.")
            QMessageBox.information(self, "Güncelleme Tamamlandı", "Yeni sürüm yüklendi. Lütfen uygulamayı yeniden başlatın.")
        except Exception as e:
            self.log(f"Güncelleme sırasında hata: {e}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AutoUpdateWindow()
    window.show()
    sys.exit(app.exec())
