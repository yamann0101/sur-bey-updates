import sys
import threading
import time
from PyQt6.QtWidgets import (
    QApplication, QWidget, QPushButton, QLabel, QTextEdit, QVBoxLayout,
    QHBoxLayout, QCheckBox
)
from PyQt6.QtGui import QFont
from PyQt6.QtCore import Qt, QTimer, QDateTime


class BotWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SUR`BEY - Güncelleme & Bot")
        self.setGeometry(400, 100, 700, 600)
        self.setStyleSheet("background-color: black; color: white;")

        main_layout = QVBoxLayout()
        self.setLayout(main_layout)

        # Başlık
        self.label = QLabel("SUR`BEY")
        self.label.setFont(QFont("Arial", 32, QFont.Weight.Bold))
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label.setStyleSheet("color: orange;")
        main_layout.addWidget(self.label)

        # Checkbox isimleri ve kutuları
        self.checkbox_names = ["HAYVANLAR", "KUTUPDEHŞETİ", "ET", "ODUN", "KÖMÜR", "DEMİR"]
        checkbox_layout = QHBoxLayout()
        self.checkboxes = []

        for name in self.checkbox_names:
            cb = QCheckBox(name)
            cb.setStyleSheet(self.checkbox_style(False))
            cb.setFont(QFont("Arial", 10))
            cb.stateChanged.connect(lambda state, checkbox=cb: self.on_checkbox_toggle(checkbox))
            self.checkboxes.append(cb)
            checkbox_layout.addWidget(cb)

        main_layout.addLayout(checkbox_layout)

        # Saat ve tarih
        self.datetime_label = QLabel()
        self.datetime_label.setFont(QFont("Consolas", 12))
        self.datetime_label.setStyleSheet("color: gray;")
        self.datetime_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(self.datetime_label)
        self.update_datetime()
        timer = QTimer(self)
        timer.timeout.connect(self.update_datetime)
        timer.start(1000)

        # Log Paneli
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setStyleSheet("background-color: #222; color: #0f0; font-family: Consolas;")
        main_layout.addWidget(self.log_output)

        # Çalıştır / Durdur Butonu
        self.toggle_button = QPushButton("Çalıştır")
        self.toggle_button.setStyleSheet("""
            QPushButton {
                background-color: orange;
                color: black;
                font-size: 18px;
                border-radius: 10px;
                padding: 10px;
                margin-top: 10px;
            }
            QPushButton:hover {
                background-color: #ffaa00;
            }
        """)
        self.toggle_button.setFixedWidth(150)
        self.toggle_button.clicked.connect(self.toggle_bot)
        main_layout.addWidget(self.toggle_button, alignment=Qt.AlignmentFlag.AlignHCenter)

        # Durum
        self.running = False
        self.bot_thread = None

    def checkbox_style(self, checked):
        if checked:
            return """
                QCheckBox {
                    color: #0f0;
                    background-color: #111;
                    border: 1px solid #0f0;
                    padding: 4px;
                    border-radius: 6px;
                }
            """
        else:
            return """
                QCheckBox {
                    color: white;
                    background-color: #111;
                    border: 1px solid white;
                    padding: 4px;
                    border-radius: 6px;
                }
            """

    def on_checkbox_toggle(self, checkbox):
        checkbox.setStyleSheet(self.checkbox_style(checkbox.isChecked()))
        state = "aktif" if checkbox.isChecked() else "pasif"
        self.log(f"[Seçim] {checkbox.text()} -> {state}")

    def update_datetime(self):
        current = QDateTime.currentDateTime().toString("dd.MM.yyyy - HH:mm:ss")
        self.datetime_label.setText(f"Güncel Zaman: {current}")

    def log(self, message):
        print(message)
        self.log_output.append(message)
        scrollbar = self.log_output.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def toggle_bot(self):
        if not self.running:
            self.running = True
            self.toggle_button.setText("Durdur")
            self.log("[BOT] Başlatıldı.")
            self.bot_thread = threading.Thread(target=self.loop_bot, daemon=True)
            self.bot_thread.start()
        else:
            self.running = False
            self.toggle_button.setText("Çalıştır")
            self.log("[BOT] Durduruldu.")

    def loop_bot(self):
        while self.running:
            self.log("[BOT] İşlem yapılıyor...")
            time.sleep(2)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = BotWindow()
    window.show()
    sys.exit(app.exec())
