import sys
import threading
import pyautogui
import os
import time
import traceback
from PyQt6.QtWidgets import (
    QApplication, QWidget, QPushButton, QLabel, QTextEdit, QVBoxLayout
)
from PyQt6.QtGui import QFont
from PyQt6.QtCore import Qt

IMAGE_DIR = r"C:\\Users\\ASUS\\Desktop\\proje_dosyasi\\image"
pyautogui.FAILSAFE = False


def log(text):
    print(text)
    if BotWindow.instance:
        BotWindow.instance.log_output.append(text)
        scrollbar = BotWindow.instance.log_output.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())


def wait_and_click(image, confidence=0.7, timeout=10, click=True):
    path = os.path.join(IMAGE_DIR, image)
    if not os.path.exists(path):
        log(f"[HATA] Görsel yok: {path}")
        return False
    start = time.time()
    while time.time() - start < timeout:
        try:
            log(f"[Bot] Aranıyor: {image}")
            loc = pyautogui.locateCenterOnScreen(path, confidence=confidence)
            if loc:
                log(f"[Bot] Bulundu: {image}")
                if click:
                    pyautogui.click(loc)
                    log(f"[Bot] Tıklandı: {image}")
                time.sleep(3)
                return True
        except Exception as e:
            log(f"[HATA] locate hatası: {e}")
        time.sleep(0.5)
    log(f"[Bot] Bulunamadı: {image}")
    return False


def click_center():
    screenWidth, screenHeight = pyautogui.size()
    pyautogui.click(screenWidth // 2, screenHeight // 2)
    log("[Bot] Ortaya tıklandı.")
    time.sleep(3)


def bulunamadi_modu():
    log("[Bot] Bulunamadı modu: merkeze tıklanıyor.")
    click_center()


def gonder_modu():
    log("[Bot] Gönder modu başladı.")
    if wait_and_click("gonder.png", timeout=3, click=False):
        if wait_and_click("odun.png", timeout=5):
            if wait_and_click("gonder.png", timeout=3):
                if wait_and_click("fmtopla.png", timeout=10):
                    wait_and_click("esitle.png", timeout=3)
                    wait_and_click("konuslandir.png", timeout=3)
                    log("[Bot] Gönder tamamlandı.")
                    return
    if wait_and_click("kapat.png", timeout=2) or wait_and_click("geri.png", timeout=2):
        time.sleep(2)
        click_center()


def dongu_modu():
    log("[Bot] Döngü modu başladı.")
    if wait_and_click("odun.png", timeout=5):
        if wait_and_click("gonder.png", timeout=5):
            if wait_and_click("fmtopla.png", timeout=10):
                wait_and_click("esitle.png", timeout=3)
                wait_and_click("konuslandir.png", timeout=3)
                log("[Bot] Döngü tamamlandı.")
                return
    if wait_and_click("kapat.png", timeout=2) or wait_and_click("geri.png", timeout=2):
        time.sleep(2)
        click_center()


def main_loop():
    log("[Bot] Başladı.")
    while True:
        hareket_var = False

        if wait_and_click("yardim.png", timeout=3):
            hareket_var = True

        if wait_and_click("ara.png", timeout=15):
            hareket_var = True
            dongu_modu()

        if wait_and_click("kapat.png", timeout=2) or wait_and_click("geri.png", timeout=2):
            log("[Bot] kapat/geri bulundu. 30 sn bekleme ve merkeze tıklama.")
            time.sleep(30)
            click_center()
            hareket_var = True
        else:
            gonder_modu()
            hareket_var = True

        if not hareket_var:
            bulunamadi_modu()

        time.sleep(3)


class BotWindow(QWidget):
    instance = None

    def __init__(self):
        super().__init__()
        BotWindow.instance = self
        self.setWindowTitle("SUR'BEY - Whiteout Botu")
        self.setGeometry(400, 100, 700, 500)
        self.setStyleSheet("background-color: black; color: white;")

        layout = QVBoxLayout()
        self.setLayout(layout)

        self.label = QLabel("SUR'BEY")
        self.label.setFont(QFont("Arial", 48, QFont.Weight.Bold))
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label.setStyleSheet("color: orange;")
        layout.addWidget(self.label)

        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setStyleSheet("background-color: #222; color: #0f0; font-family: Consolas;")
        layout.addWidget(self.log_output)

        self.button = QPushButton("Başlat")
        self.button.setStyleSheet("""
            QPushButton {
                background-color: orange;
                color: black;
                font-size: 18px;
                border-radius: 10px;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #ffaa00;
            }
        """)
        self.button.clicked.connect(self.start_bot)
        layout.addWidget(self.button)

    def start_bot(self):
        self.button.setEnabled(False)
        self.button.setText("Çalışıyor...")
        threading.Thread(target=self.run_bot, daemon=True).start()

    def run_bot(self):
        try:
            main_loop()
        except Exception as e:
            log(f"[HATA] Bot çöktü: {e}")
            traceback.print_exc()
        finally:
            self.button.setEnabled(True)
            self.button.setText("Başlat")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = BotWindow()
    window.show()
    sys.exit(app.exec())
