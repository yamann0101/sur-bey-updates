import sys
import threading
import time
from PyQt6.QtWidgets import (
    QApplication, QWidget, QPushButton, QLabel, QTextEdit, QVBoxLayout
)
from PyQt6.QtGui import QFont
from PyQt6.QtCore import Qt

class BotWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SUR`BEY - Güncelleme & Bot")
        self.setGeometry(400, 100, 700, 500)
        self.setStyleSheet("background-color: black; color: white;")

        layout = QVBoxLayout()
        self.setLayout(layout)

        # Başlık
        self.label = QLabel("SUR`BEY")
        self.label.setFont(QFont("Arial", 48, QFont.Weight.Bold))
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label.setStyleSheet("color: orange;")
        layout.addWidget(self.label)

        # Log Paneli
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setStyleSheet("background-color: #222; color: #0f0; font-family: Consolas;")
        layout.addWidget(self.log_output)

        # Başlat Butonu
        self.start_button = QPushButton("Başlat")
        self.start_button.setStyleSheet("""
            QPushButton {
                background-color: orange;
                color: black;
                font-size: 18px;
                border-radius: 10px;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #ffaa00;
            }
        """)
        self.start_button.clicked.connect(self.start_bot)
        layout.addWidget(self.start_button)

        # Durdur/Çalıştır Butonu
        self.toggle_button = QPushButton("Durdur")
        self.toggle_button.setStyleSheet("""
            QPushButton {
                background-color: orange;
                color: black;
                font-size: 18px;
                border-radius: 10px;
                padding: 10px;
                margin-top: 10px;
            }
            QPushButton:hover {
                background-color: #ffaa00;
            }
        """)
        self.toggle_button.setFixedWidth(150)
        self.toggle_button.clicked.connect(self.toggle_bot)
        layout.addWidget(self.toggle_button, alignment=Qt.AlignmentFlag.AlignHCenter)

        # Bot kontrolü
        self.running = True
        self.bot_started = False

    def log(self, message):
        print(message)
        self.log_output.append(message)
        scrollbar = self.log_output.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def start_bot(self):
        if not self.bot_started:
            self.bot_started = True
            self.log("[BOT] Başlatılıyor...")
            self.thread = threading.Thread(target=self.loop_bot, daemon=True)
            self.thread.start()
            self.start_button.setEnabled(False)
            self.start_button.setText("Çalışıyor...")

    def toggle_bot(self):
        self.running = not self.running
        if self.running:
            self.log("[BOT] Devam ediyor...")
            self.toggle_button.setText("Durdur")
        else:
            self.log("[BOT] Durduruldu.")
            self.toggle_button.setText("Çalıştır")

    def loop_bot(self):
        self.log("[BOT] Döngü başladı.")
        while True:
            if self.running:
                self.log("[BOT] İşlem yapılıyor...")
                # Buraya işlemlerini koyabilirsin
                time.sleep(2)
            else:
                time.sleep(1)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = BotWindow()
    window.show()
    sys.exit(app.exec())
