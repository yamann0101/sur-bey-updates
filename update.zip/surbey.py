import sys
import threading
import time
import requests
import zipfile
import os
from PyQt6.QtWidgets import (
    QApplication, QWidget, QPushButton, QLabel, QTextEdit, QVBoxLayout, QHBoxLayout, QMessageBox
)
from PyQt6.QtGui import QFont
from PyQt6.QtCore import Qt, QTimer, QDateTime

CURRENT_VERSION = "1.0.0"
VERSION_URL = "https://raw.githubusercontent.com/yamann0101/sur-bey-updates/main/version.txt"
UPDATE_URL = "https://github.com/yamann0101/sur-bey-updates/raw/main/update.zip"

class BotWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SUR'BEY - Güncellenebilir Bot")
        self.setGeometry(400, 100, 700, 500)
        self.setStyleSheet("background-color: black; color: white;")
        self.running = False
        self.bot_thread = None

        main_layout = QVBoxLayout()
        self.setLayout(main_layout)

        # Üst Kısım: Başlık ve Güncelleme Butonu
        header_layout = QHBoxLayout()
        self.title_label = QLabel("SUR'BEY")
        self.title_label.setFont(QFont("Arial", 32, QFont.Weight.Bold))
        self.title_label.setStyleSheet("color: orange;")
        header_layout.addWidget(self.title_label)

        self.update_button = QPushButton("Güncellemeleri Kontrol Et")
        self.update_button.setStyleSheet("background-color: orange; color: black; font-size: 14px; padding: 6px;")
        self.update_button.clicked.connect(self.check_for_updates)
        header_layout.addWidget(self.update_button, alignment=Qt.AlignmentFlag.AlignRight)

        main_layout.addLayout(header_layout)

        # Canlı Tarih & Saat
        self.datetime_label = QLabel()
        self.datetime_label.setFont(QFont("Consolas", 14))
        self.datetime_label.setStyleSheet("color: lightgreen;")
        self.datetime_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(self.datetime_label)

        timer = QTimer(self)
        timer.timeout.connect(self.update_datetime)
        timer.start(1000)  # 1 saniyede bir güncelle
        self.update_datetime()  # Başlangıçta da göster

        # Log Paneli
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setStyleSheet("background-color: #222; color: #0f0; font-family: Consolas;")
        main_layout.addWidget(self.log_output)

        # Çalıştır / Durdur Butonu
        self.toggle_button = QPushButton("Çalıştır")
        self.toggle_button.setFixedWidth(150)
        self.toggle_button.setStyleSheet("""
            QPushButton {
                background-color: orange;
                color: black;
                font-size: 18px;
                border-radius: 10px;
                padding: 10px;
                margin-top: 10px;
            }
            QPushButton:hover {
                background-color: #ffaa00;
            }
        """)
        self.toggle_button.clicked.connect(self.toggle_bot)
        main_layout.addWidget(self.toggle_button, alignment=Qt.AlignmentFlag.AlignHCenter)

    def log(self, message):
        print(message)
        self.log_output.append(message)
        scrollbar = self.log_output.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def toggle_bot(self):
        if not self.running:
            self.running = True
            self.toggle_button.setText("Durdur")
            self.log("[BOT] Başlatıldı.")
            self.bot_thread = threading.Thread(target=self.loop_bot, daemon=True)
            self.bot_thread.start()
        else:
            self.running = False
            self.toggle_button.setText("Çalıştır")
            self.log("[BOT] Durduruldu.")

    def loop_bot(self):
        while self.running:
            self.log("[BOT] İşlem yapılıyor...")
            time.sleep(2)

    def update_datetime(self):
        current = QDateTime.currentDateTime()
        self.datetime_label.setText(current.toString("dd.MM.yyyy - HH:mm:ss"))

    def check_for_updates(self):
        try:
            self.log("[Güncelleme] Sürüm kontrol ediliyor...")
            r = requests.get(VERSION_URL)
            if r.status_code == 200:
                latest_version = r.text.strip()
                if latest_version != CURRENT_VERSION:
                    self.log(f"[Güncelleme] Yeni sürüm bulundu: {latest_version}")
                    self.download_and_install_update()
                else:
                    self.log("[Güncelleme] Zaten güncelsiniz.")
            else:
                self.log("[HATA] Sürüm dosyasına erişilemedi.")
        except Exception as e:
            self.log(f"[HATA] Güncelleme kontrol hatası: {e}")

    def download_and_install_update(self):
        try:
            self.log("[Güncelleme] Güncelleme indiriliyor...")
            r = requests.get(UPDATE_URL)
            update_path = "update.zip"
            with open(update_path, "wb") as f:
                f.write(r.content)

            self.log("[Güncelleme] Güncelleme indirildi, açılıyor...")
            with zipfile.ZipFile(update_path, "r") as zip_ref:
                zip_ref.extractall(".")

            os.remove(update_path)
            self.log("[Güncelleme] Güncelleme tamamlandı. Programı yeniden başlatın.")

            QMessageBox.information(self, "Güncelleme", "Yeni sürüm yüklendi. Lütfen uygulamayı yeniden başlatın.")
        except Exception as e:
            self.log(f"[HATA] Güncelleme indirilemedi: {e}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = BotWindow()
    window.show()
    sys.exit(app.exec())
