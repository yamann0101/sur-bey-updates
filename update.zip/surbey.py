import sys
import requests
import zipfile
import io
import os
from packaging import version
from PyQt6.QtWidgets import (
    QApplication, QWidget, QLabel, QTextEdit, QVBoxLayout, QMessageBox
)
from PyQt6.QtGui import QFont
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal

# --- Ayarlar ---
VERSION_FILE = "current_version.txt"  # Yerel sürüm bilgisini saklayan dosya
VERSION_URL = "https://raw.githubusercontent.com/yamann0101/sur-bey-updates/main/version.txt"
UPDATE_ZIP_URL = "https://github.com/yamann0101/sur-bey-updates/raw/main/update.zip"

# --- Yardımcı fonksiyonlar ---

def get_local_version():
    if not os.path.exists(VERSION_FILE):
        with open(VERSION_FILE, "w") as f:
            f.write("1.0.0")  # İlk sürüm
        return "1.0.0"
    with open(VERSION_FILE, "r") as f:
        return f.read().strip()

def set_local_version(new_version):
    with open(VERSION_FILE, "w") as f:
        f.write(new_version)

# --- Güncelleme işlemi bir thread’de çalışacak (arayüzü bloklamasın diye) ---

class UpdateThread(QThread):
    log_signal = pyqtSignal(str)
    update_finished = pyqtSignal(bool, str)

    def run(self):
        try:
            self.log_signal.emit("Güncelleme kontrol ediliyor...")
            local_version = get_local_version()
            self.log_signal.emit(f"Yerel sürüm: {local_version}")

            r = requests.get(VERSION_URL, timeout=10)
            if r.status_code != 200:
                self.log_signal.emit("version.txt dosyasına ulaşılamadı!")
                self.update_finished.emit(False, "version.txt dosyasına ulaşılamadı!")
                return

            latest_version = r.text.strip()
            self.log_signal.emit(f"Güncel sürüm: {latest_version}")

            if version.parse(latest_version) > version.parse(local_version):
                self.log_signal.emit("Yeni sürüm bulundu. İndiriliyor...")
                r2 = requests.get(UPDATE_ZIP_URL, timeout=30)
                if r2.status_code != 200:
                    self.log_signal.emit("Güncelleme dosyası indirilemedi!")
                    self.update_finished.emit(False, "Güncelleme dosyası indirilemedi!")
                    return

                with zipfile.ZipFile(io.BytesIO(r2.content)) as zip_file:
                    zip_file.extractall(".")  # Şimdilik aynı klasöre açıyor
                self.log_signal.emit("Güncelleme tamamlandı.")
                set_local_version(latest_version)
                self.update_finished.emit(True, "Güncelleme başarılı. Lütfen uygulamayı yeniden başlatın.")
            else:
                self.log_signal.emit("Uygulama zaten güncel.")
                self.update_finished.emit(False, "Uygulama zaten güncel.")
        except Exception as e:
            self.log_signal.emit(f"Hata: {e}")
            self.update_finished.emit(False, f"Hata: {e}")

# --- Ana pencere ---

class AutoUpdateApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SUR'BEY Otomatik Güncelleme")
        self.setGeometry(400, 100, 700, 500)
        self.setStyleSheet("background-color: black; color: white;")

        layout = QVBoxLayout()
        self.setLayout(layout)

        self.label = QLabel("SUR'BEY")
        self.label.setFont(QFont("Arial", 48, QFont.Weight.Bold))
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label.setStyleSheet("color: orange;")
        layout.addWidget(self.label)

        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setStyleSheet("background-color: #222; color: #0f0; font-family: Consolas;")
        layout.addWidget(self.log_output)

        self.update_thread = UpdateThread()
        self.update_thread.log_signal.connect(self.log)
        self.update_thread.update_finished.connect(self.on_update_finished)

        # Uygulama açılır açılmaz otomatik güncelleme başlat
        QTimer.singleShot(1000, self.start_update)

    def log(self, text):
        self.log_output.append(text)

    def start_update(self):
        self.log("Otomatik güncelleme başlıyor...")
        if not self.update_thread.isRunning():
            self.update_thread.start()

    def on_update_finished(self, updated, message):
        if updated:
            QMessageBox.information(self, "Güncelleme Tamamlandı", message)
        else:
            # Güncel ya da hata mesajı burada gösterilebilir
            # İstersen sadece log'ta bırakabilirsin
            self.log(message)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AutoUpdateApp()
    window.show()
    sys.exit(app.exec())
