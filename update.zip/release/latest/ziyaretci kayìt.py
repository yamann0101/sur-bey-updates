import tkinter as tk
from tkinter import ttk, messagebox
import sys
from datetime import datetime
from openpyxl import Workbook, load_workbook
import os
import json
import requests
import zipfile
import shutil

# Uygulamanın mevcut sürümü
CURRENT_VERSION = "1.0.0"

class VisitorApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Ziyaretçi Kayıt Sistemi")
        self.root.geometry("1250x800")
        self.root.configure(bg="#0a0a0a")

        # Pencereyi ekranın ortasına hizala (İlk başlangıç boyutu için)
        self.center_window()

        # Tema değişkenleri
        self.is_dark_theme = True
        self.all_data = []
        self.current_user_type = None
        self.current_user_name = None

        # RGB animasyon değişkenleri
        self.rgb_index = 0
        self.rgb_colors = ["#FF0000", "#FF4000", "#FF8000", "#FFBF00", "#FFFF00", 
                          "#BFFF00", "#80FF00", "#40FF00", "#00FF00", "#00FF40",
                          "#00FF80", "#00FFBF", "#00FFFF", "#00BFFF", "#0080FF",
                          "#0040FF", "#0000FF", "#4000FF", "#8000FF", "#BF00FF",
                          "#FF00FF", "#FF00BF", "#FF0080", "#FF0040"]

        # Hoş geldiniz animasyon değişkenleri
        # Kayan yazı için hala piksel tabanlı hareket gerekiyor, bu yüzden relx/rely kullanmıyoruz.
        # Genişlikten bağımsız hareket etmesi için dinamik hesaplama yapılmalıydı ama bu talebin dışında.
        self.welcome_x = 1250
        self.welcome_direction = -2

        # Ziyaretçi Sayısı ile İlgili Değişkenler
        self.inside_visitors_count = 0
        self.current_rgb_color_index = 0
        self.count_label_main = None
        self.count_label_visitor = None
        self.tree = None

        # ERHAN YAMAN label referansı
        self.erhan_label = None

        # Arama giriş alanları
        self.search_plate_entry = None
        self.search_name_surname_entry = None

        # Listbox referansı
        self.visitor_listbox = None

        # Listbox başlık genişliklerini burada tanımladım
        # Bu değerler Courier New 10pt fontuna göre optimize edilmiştir.
        self.header_widths = {
            "D": 3,   # Durum (🟢/🔴 ve bir boşluk için, örn: "🟢 ")
            "İSİM": 10, 
            "SOYİSİM": 10, 
            "FİRMA": 12,  
            "PLAKA": 9,  
            "GELİŞ NEDENİ": 16, 
            "KİME GELDİ": 14,   
            "GİRİŞ": 10,  # Daha da sağa kaydırıldı
            "ÇIKIŞ": 10,  # Daha da sağa kaydırıldı
            "TARİH": 14, # Daha da sağa kaydırıldı
            "KAYIT YAPAN P.": 16, 
            "AÇIKLAMA": 35 
        }

        # Kullanıcı verilerini yükle
        self.load_users()

        # Ana giriş ekranını oluştur
        self.create_main_screen()

    def center_window(self):
        """Pencereyi ekranın ortasına hizalar"""
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth() - 1250) // 2
        y = (self.root.winfo_screenheight() - 800) // 2
        self.root.geometry(f"1250x800+{x}+{y}")

    def animate_rgb_text(self):
        """ERHAN YAMAN yazısını RGB renklerle animasyon yapar"""
        if self.erhan_label and self.erhan_label.winfo_exists():
            color = self.rgb_colors[self.rgb_index]
            self.erhan_label.config(fg=color)
            self.rgb_index = (self.rgb_index + 1) % len(self.rgb_colors)
        self.root.after(100, self.animate_rgb_text)

    def animate_welcome_text(self):
        """Hoş geldiniz yazısını kayan animasyon yapar"""
        if hasattr(self, 'welcome_label') and self.welcome_label.winfo_exists():
            color = self.rgb_colors[self.rgb_index % len(self.rgb_colors)]
            self.welcome_label.config(fg=color)

            self.welcome_x += self.welcome_direction

            # Yazı tamamen soldan çıktığında sağdan başlat
            if self.welcome_x < -600:
                self.welcome_x = 1250

            self.welcome_label.place(x=self.welcome_x, y=25)

        self.root.after(30, self.animate_welcome_text)

    def load_users(self):
        """Kullanıcı verilerini yükler"""
        self.users_file = "users.json"
        self.users = {
            "ADMIN": {"password": "admin123", "type": "admin", "fullname": "Yönetici"},
            "USER": {"password": "user123", "type": "user", "fullname": "Kullanıcı"}
        }

        if os.path.exists(self.users_file):
            try:
                with open(self.users_file, 'r', encoding='utf-8') as f:
                    loaded_users = json.load(f)
                    for username, user_data in loaded_users.items():
                        if "fullname" not in user_data:
                            user_data["fullname"] = username
                    self.users = loaded_users
            except:
                pass

    def save_users(self):
        """Kullanıcı verilerini kaydeder"""
        try:
            with open(self.users_file, 'w', encoding='utf-8') as f:
                json.dump(self.users, f, ensure_ascii=False, indent=2)
        except Exception as e:
            messagebox.showerror("Hata", f"Kullanıcı verilerini kaydetme hatası: {str(e)}")

    def create_main_screen(self):
        """Ultra modern ana giriş ekranını oluşturur"""
        for widget in self.root.winfo_children():
            widget.destroy()

        self.root.configure(bg="#0a0a0a")

        # Ana container frame
        main_frame = tk.Frame(self.root, bg="#0a0a0a")
        main_frame.pack(fill="both", expand=True)

        # Üst kısım - Kayan hoş geldiniz yazısı (konumu sabit pikselde kalacak)
        header_frame = tk.Frame(main_frame, bg="#0a0a0a", height=80)
        header_frame.pack(fill="x", pady=(10, 0))
        header_frame.pack_propagate(False)

        self.welcome_label = tk.Label(header_frame, 
                                    text="🏢 ZİYARETÇİ KAYIT PANELİNE HOŞ GELDİNİZ 🏢", 
                                    font=("Segoe UI", 18, "bold"),
                                    bg="#0a0a0a")
        self.welcome_label.place(x=1250, y=25) # Bu hala piksel tabanlı, çünkü kayan bir animasyon.

        # Kayan animasyon başlat
        self.animate_welcome_text()

        # Sağ alt köşe - ERHAN YAMAN yazısı
        # relx=1.0, rely=1.0 -> sağ alt köşe
        # x=-10, y=-10 -> sağ ve alttan 10 piksel içeride
        # anchor='se' -> widget'ın sağ alt köşesi belirtilen (relx, rely) noktasına hizalanır.
        self.erhan_label = tk.Label(self.root,
                                  text="ERHAN YAMAN",
                                  font=("Segoe UI", 12, "bold"),
                                  bg="#0a0a0a")
        self.erhan_label.place(relx=1.0, rely=1.0, x=-10, y=-10, anchor='se')

        # RGB animasyon başlat
        self.animate_rgb_text()

        # Ana başlık (ortada kalacak)
        title_frame = tk.Frame(main_frame, bg="#0a0a0a")
        title_frame.pack(pady=(20, 30))

        main_title = tk.Label(title_frame, 
                             text="ZİYARETÇİ KAYIT SİSTEMİ", 
                             font=("Segoe UI", 32, "bold"),
                             fg="#00d4ff",
                             bg="#0a0a0a")
        main_title.pack()

        subtitle = tk.Label(title_frame,
                           text="Modern Güvenlik Yönetim Platformu",
                           font=("Segoe UI", 14),
                           fg="#888888",
                           bg="#0a0a0a")
        subtitle.pack(pady=(5, 0))

        # Login container (Ekranın ortasında kalacak)
        # relx=0.5, rely=0.5 -> Parent'ın (main_frame) tam ortası
        # anchor='center' -> Widget'ın merkezinin belirtilen (relx, rely) noktasına hizalanır.
        glow_frame = tk.Frame(main_frame, bg="#00d4ff", height=404, width=504)
        glow_frame.place(relx=0.5, rely=0.5, anchor='center')

        # Login frame (Glow frame içinde ortada kalacak)
        login_frame = tk.Frame(glow_frame, bg="#1a1a1a", height=400, width=500)
        login_frame.place(relx=0.5, rely=0.5, anchor='center')
        login_frame.pack_propagate(False)

        # Login başlığı
        login_title = tk.Label(login_frame,
                              text="🔐 SİSTEM GİRİŞİ",
                              font=("Segoe UI", 20, "bold"),
                              fg="#00d4ff",
                              bg="#1a1a1a")
        login_title.pack(pady=(30, 40))

        # Kullanıcı adı
        user_label = tk.Label(login_frame,
                             text="KULLANICI ADI:",
                             font=("Segoe UI", 12, "bold"),
                             fg="#ffffff",
                             bg="#1a1a1a")
        user_label.pack(pady=(0, 5))

        self.username_entry = tk.Entry(login_frame,
                                      font=("Segoe UI", 14),
                                      bg="#2a2a2a",
                                      fg="#ffffff",
                                      insertbackground="#00d4ff",
                                      relief="flat",
                                      bd=0,
                                      width=25)
        self.username_entry.pack(pady=(0, 20), ipady=8)

        # Şifre
        pass_label = tk.Label(login_frame,
                             text="ŞİFRE:",
                             font=("Segoe UI", 12, "bold"),
                             fg="#ffffff",
                             bg="#1a1a1a")
        pass_label.pack(pady=(0, 5))

        self.password_entry = tk.Entry(login_frame,
                                      font=("Segoe UI", 14),
                                      bg="#2a2a2a",
                                      fg="#ffffff",
                                      insertbackground="#00d4ff",
                                      relief="flat",
                                      bd=0,
                                      width=25,
                                      show="*")
        self.password_entry.pack(pady=(0, 30), ipady=8)

        # Login butonu
        login_btn = tk.Button(login_frame,
                             text="🚀 SİSTEME GİR",
                             font=("Segoe UI", 14, "bold"),
                             bg="#00d4ff",
                             fg="#000000",
                             relief="flat",
                             bd=0,
                             width=20,
                             command=self.login,
                             cursor="hand2")
        login_btn.pack(pady=10, ipady=5)

        # Enter tuşu ile giriş
        self.password_entry.bind("<Return>", lambda e: self.login())
        self.username_entry.bind("<Return>", lambda e: self.password_entry.focus())

        # Güncelleme butonu
        update_btn = tk.Button(login_frame,
                              text="🔄 GÜNCELLEME KONTROL ET",
                              font=("Segoe UI", 10),
                              bg="#333333",
                              fg="#ffffff",
                              relief="flat",
                              bd=0,
                              command=self.check_for_updates,
                              cursor="hand2")
        update_btn.pack(pady=(20, 0))

        # Focus
        self.username_entry.focus()

    def login(self):
        """Kullanıcı giriş kontrolü"""
        username = self.username_entry.get().strip().upper()
        password = self.password_entry.get().strip()

        if not username or not password:
            messagebox.showwarning("Uyarı", "Kullanıcı adı ve şifre gereklidir!")
            return

        if username in self.users and self.users[username]["password"] == password:
            self.current_user_type = self.users[username]["type"]
            self.current_user_name = self.users[username]["fullname"]

            if self.current_user_type == "admin":
                self.create_admin_menu()
            else:
                self.show_visitor_panel()
        else:
            messagebox.showerror("Hata", "Geçersiz kullanıcı adı veya şifre!")

    def create_admin_menu(self):
        """Modern admin menüsünü oluşturur"""
        self.clear_window()
        self.root.configure(bg="#0a0a0a")

        # ERHAN YAMAN yazısını tekrar ekle (sağ alt köşede sabit)
        self.erhan_label = tk.Label(self.root,
                                  text="ERHAN YAMAN",
                                  font=("Segoe UI", 12, "bold"),
                                  bg="#0a0a0a")
        self.erhan_label.place(relx=1.0, rely=1.0, x=-10, y=-10, anchor='se')
        self.animate_rgb_text()

        # Ana başlık
        title_label = tk.Label(self.root,
                              text="🛡️ YÖNETİCİ PANELİ",
                              font=("Segoe UI", 28, "bold"),
                              fg="#00d4ff",
                              bg="#0a0a0a")
        title_label.pack(pady=(30, 10))

        subtitle = tk.Label(self.root,
                           text=f"Hoş geldiniz, {self.current_user_name}",
                           font=("Segoe UI", 14),
                           fg="#888888",
                           bg="#0a0a0a")
        subtitle.pack(pady=(0, 40))

        # Buton container
        button_container = tk.Frame(self.root, bg="#0a0a0a")
        button_container.pack(expand=True)

        # Butonlar için grid layout
        buttons_info = [
            ("👥 ZİYARETÇİ PANELİ", self.show_visitor_panel, "#00d4ff"),
            ("⚙️ KULLANICI YÖNETİMİ", self.show_user_management, "#ff6b35"),
            ("🔄 GÜNCELLEME KONTROL", self.check_for_updates, "#4ecdc4"),
            ("🚪 ÇIKIŞ", self.logout, "#ff5555")
        ]

        for i, (text, command, color) in enumerate(buttons_info):
            row = i // 2
            col = i % 2

            btn_frame = tk.Frame(button_container, bg=color, height=82, width=302)
            btn_frame.grid(row=row, column=col, padx=20, pady=15)
            btn_frame.pack_propagate(False)

            btn = tk.Button(btn_frame,
                           text=text,
                           font=("Segoe UI", 14, "bold"),
                           bg="#1a1a1a",
                           fg="#ffffff",
                           relief="flat",
                           bd=0,
                           command=command,
                           cursor="hand2")
            btn.place(x=2, y=2, width=298, height=78)

        # İçerideki ziyaretçi sayısı
        self.load_data_for_count()
        self.update_inside_visitors_count()

        self.count_label_main = tk.Label(self.root,
                                        text=f"İçerideki Ziyaretçi Sayısı: {self.inside_visitors_count}",
                                        font=("Segoe UI", 16, "bold"),
                                        fg="#00ff00",
                                        bg="#0a0a0a")
        self.count_label_main.pack(pady=(30, 0))

    def show_user_management(self):
        """Modern kullanıcı yönetim panelini gösterir"""
        self.clear_window()
        self.root.configure(bg="#0a0a0a")

        # ERHAN YAMAN yazısını tekrar ekle (sağ alt köşede sabit)
        self.erhan_label = tk.Label(self.root,
                                  text="ERHAN YAMAN",
                                  font=("Segoe UI", 12, "bold"),
                                  bg="#0a0a0a")
        self.erhan_label.place(relx=1.0, rely=1.0, x=-10, y=-10, anchor='se')
        self.animate_rgb_text()

        # Başlık
        title_label = tk.Label(self.root,
                              text="👥 KULLANICI YÖNETİMİ",
                              font=("Segoe UI", 24, "bold"),
                              fg="#ff6b35",
                              bg="#0a0a0a")
        title_label.pack(pady=(20, 30))

        # Yeni kullanıcı ekleme frame
        add_frame = tk.Frame(self.root, bg="#1a1a1a", relief="flat", bd=2)
        add_frame.pack(pady=20, padx=50, fill="x")

        # Glow efekti
        glow_frame = tk.Frame(self.root, bg="#ff6b35", height=104)
        glow_frame.pack(pady=(0, 20), padx=48, fill="x")

        add_frame_inner = tk.Frame(glow_frame, bg="#1a1a1a")
        add_frame_inner.pack(fill="both", expand=True, padx=2, pady=2)

        tk.Label(add_frame_inner,
                text="YENİ KULLANICI EKLE",
                font=("Segoe UI", 14, "bold"),
                fg="#ff6b35",
                bg="#1a1a1a").pack(pady=10)

        # Input alanları
        input_frame = tk.Frame(add_frame_inner, bg="#1a1a1a")
        input_frame.pack(pady=10)

        tk.Label(input_frame, text="Kullanıcı Adı:", fg="#ffffff", bg="#1a1a1a",
                font=("Segoe UI", 10)).grid(row=0, column=0, padx=5, sticky="w")
        self.new_username_entry = tk.Entry(input_frame, bg="#2a2a2a", fg="#ffffff",
                                          relief="flat", bd=0, font=("Segoe UI", 10))
        self.new_username_entry.grid(row=0, column=1, padx=5)

        tk.Label(input_frame, text="Şifre:", fg="#ffffff", bg="#1a1a1a",
                font=("Segoe UI", 10)).grid(row=0, column=2, padx=5, sticky="w")
        self.new_password_entry = tk.Entry(input_frame, bg="#2a2a2a", fg="#ffffff",
                                          relief="flat", bd=0, font=("Segoe UI", 10))
        self.new_password_entry.grid(row=0, column=3, padx=5)

        tk.Label(input_frame, text="Ad Soyad:", fg="#ffffff", bg="#1a1a1a",
                font=("Segoe UI", 10)).grid(row=0, column=4, padx=5, sticky="w")
        self.new_fullname_entry = tk.Entry(input_frame, bg="#2a2a2a", fg="#ffffff",
                                          relief="flat", bd=0, font=("Segoe UI", 10))
        self.new_fullname_entry.grid(row=0, column=5, padx=5)

        tk.Label(input_frame, text="Tip:", fg="#ffffff", bg="#1a1a1a",
                font=("Segoe UI", 10)).grid(row=0, column=6, padx=5, sticky="w")
        self.user_type_var = tk.StringVar(value="user")
        type_combo = ttk.Combobox(input_frame, textvariable=self.user_type_var,
                                 values=["user", "admin"], state="readonly", width=8)
        type_combo.grid(row=0, column=7, padx=5)

        add_btn = tk.Button(input_frame,
                           text="➕ EKLE",
                           bg="#00d4ff",
                           fg="#000000",
                           relief="flat",
                           bd=0,
                           font=("Segoe UI", 10, "bold"),
                           command=self.add_new_user,
                           cursor="hand2")
        add_btn.grid(row=0, column=8, padx=10)

        # Kullanıcı listesi
        list_frame = tk.Frame(self.root, bg="#1a1a1a")
        list_frame.pack(pady=20, padx=50, fill="both", expand=True)

        tk.Label(list_frame,
                text="MEVCUT KULLANICILAR",
                font=("Segoe UI", 14, "bold"),
                fg="#ffffff",
                bg="#1a1a1a").pack(pady=10)

        # Treeview
        columns = ("Kullanıcı Adı", "Ad Soyad", "Tip")
        self.user_tree = ttk.Treeview(list_frame, columns=columns, show="headings", height=10)

        for col in columns:
            self.user_tree.heading(col, text=col)
            self.user_tree.column(col, width=200, anchor="center")

        # Scrollbar
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.user_tree.yview)
        self.user_tree.configure(yscrollcommand=scrollbar.set)

        self.user_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Kullanıcıları yükle
        self.load_users_to_tree()

        # Butonlar
        btn_frame = tk.Frame(self.root, bg="#0a0a0a")
        btn_frame.pack(pady=20)

        delete_btn = tk.Button(btn_frame,
                              text="🗑️ SEÇİLİ KULLANICIYI SİL",
                              font=("Segoe UI", 12, "bold"),
                              bg="#ff5555",
                              fg="#ffffff",
                              relief="flat",
                              bd=0,
                              command=self.delete_selected_user,
                              cursor="hand2")
        delete_btn.pack(side="left", padx=10)

        back_btn = tk.Button(btn_frame,
                            text="🔙 GERİ DÖN",
                            font=("Segoe UI", 12, "bold"),
                            bg="#666666",
                            fg="#ffffff",
                            relief="flat",
                            bd=0,
                            command=self.create_admin_menu,
                            cursor="hand2")
        back_btn.pack(side="left", padx=10)

    def load_users_to_tree(self):
        """Kullanıcıları tree'ye yükler"""
        for item in self.user_tree.get_children():
            self.user_tree.delete(item)

        for username, user_data in self.users.items():
            self.user_tree.insert("", "end", values=(
                username, 
                user_data.get("fullname", username),
                user_data["type"]
            ))

    def add_new_user(self):
        """Yeni kullanıcı ekler"""
        username = self.new_username_entry.get().strip().upper()
        password = self.new_password_entry.get().strip()
        fullname = self.new_fullname_entry.get().strip()
        user_type = self.user_type_var.get()

        if not username or not password or not fullname:
            messagebox.showwarning("Uyarı", "Tüm alanları doldurunuz!")
            return

        if username in self.users:
            messagebox.showerror("Hata", "Bu kullanıcı adı zaten mevcut!")
            return

        self.users[username] = {
            "password": password,
            "type": user_type,
            "fullname": fullname
        }

        self.save_users()
        self.load_users_to_tree()

        # Alanları temizle
        self.new_username_entry.delete(0, tk.END)
        self.new_password_entry.delete(0, tk.END)
        self.new_fullname_entry.delete(0, tk.END)

        messagebox.showinfo("Başarılı", f"Kullanıcı '{username}' başarıyla eklendi!")

    def delete_selected_user(self):
        """Seçili kullanıcıyı siler"""
        selection = self.user_tree.selection()
        if not selection:
            messagebox.showwarning("Uyarı", "Lütfen silinecek kullanıcıyı seçiniz!")
            return

        username = self.user_tree.item(selection[0], "values")[0]

        if username == "ADMIN":
            messagebox.showerror("Hata", "Ana yönetici hesabı silinemez!")
            return

        if messagebox.askyesno("Onay", f"'{username}' kullanıcısını silmek istediğinizden emin misiniz?"):
            del self.users[username]
            self.save_users()
            self.user_tree.delete(selection[0])
            messagebox.showinfo("Başarılı", f"Kullanıcı '{username}' başarıyla silindi!")

    def show_visitor_panel(self):
        """Ana ziyaretçi panelini gösterir"""
        self.clear_window()
        self.create_visitor_panel()

    def create_visitor_panel(self):
        """Modern ziyaretçi kayıt panelini oluşturur"""
        self.root.configure(bg="#0a0a0a")

        # ERHAN YAMAN yazısını tekrar ekle (sağ alt köşede sabit)
        self.erhan_label = tk.Label(self.root,
                                  text="ERHAN YAMAN",
                                  font=("Segoe UI", 12, "bold"),
                                  bg="#0a0a0a")
        self.erhan_label.place(relx=1.0, rely=1.0, x=-10, y=-10, anchor='se')
        self.animate_rgb_text()

        # Ana başlık
        title_label = tk.Label(self.root,
                              text="👥 ZİYARETÇİ KAYIT PANELİ",
                              font=("Segoe UI", 24, "bold"),
                              fg="#00d4ff",
                              bg="#0a0a0a")
        title_label.pack(pady=(10, 5))

        # Kullanıcı bilgisi ve ziyaretçi sayısı
        info_frame = tk.Frame(self.root, bg="#0a0a0a")
        info_frame.pack(pady=5)

        user_info = tk.Label(info_frame,
                            text=f"Kullanıcı: {self.current_user_name}",
                            font=("Segoe UI", 12),
                            fg="#888888",
                            bg="#0a0a0a")
        user_info.pack(side="left", padx=20)

        # İçerideki ziyaretçi sayısı
        self.load_data_for_count()
        self.update_inside_visitors_count()

        self.count_label_visitor = tk.Label(info_frame,
                                           text=f"İçerideki Ziyaretçi Sayısı: {self.inside_visitors_count}",
                                           font=("Segoe UI", 12, "bold"),
                                           fg="#00ff00",
                                           bg="#0a0a0a")
        self.count_label_visitor.pack(side="right", padx=20)

        # Ana container
        main_container = tk.Frame(self.root, bg="#0a0a0a")
        main_container.pack(fill="both", expand=True, padx=10, pady=10)

        # Sol panel - Form
        form_frame = tk.Frame(main_container, bg="#1a1a1a", width=400)
        form_frame.pack(side="left", fill="y", padx=(0, 5))
        form_frame.pack_propagate(False)

        # Form başlığı
        form_title = tk.Label(form_frame,
                             text="📝 YENİ ZİYARETÇİ KAYDI",
                             font=("Segoe UI", 16, "bold"),
                             fg="#00d4ff",
                             bg="#1a1a1a")
        form_title.pack(pady=20)

        # Form alanları
        self.entries = {}
        fields = [
            ("İSİM", "#ff6b35"),
            ("SOYİSİM", "#ff6b35"),
            ("FİRMA", "#4ecdc4"),
            ("PLAKA", "#ffd93d"),
            ("GELİŞ NEDENİ", "#6c5ce7"),
            ("KİME GELDİ", "#a29bfe"),
            ("GİRİŞ SAATİ", "#00b894"),
            ("ÇIKIŞ SAATİ", "#e17055"),
            ("TARİH", "#fdcb6e"),
            ("KAYIT YAPAN P.", "#fd79a8"),
            ("AÇIKLAMA", "#74b9ff") 
        ]

        for field, color in fields:
            field_frame = tk.Frame(form_frame, bg="#1a1a1a")
            field_frame.pack(fill="x", padx=20, pady=5)

            label = tk.Label(field_frame,
                           text=field + ":",
                           font=("Segoe UI", 10, "bold"),
                           fg=color,
                           bg="#1a1a1a",
                           width=15,
                           anchor="w")
            label.pack(side="left")

            entry = tk.Entry(field_frame,
                           font=("Segoe UI", 10),
                           bg="#2a2a2a",
                           fg="#ffffff",
                           insertbackground="#00d4ff",
                           relief="flat",
                           bd=0,
                           exportselection=False) # Seçimi korumak için
            entry.pack(side="right", fill="x", expand=True, ipady=3)

            # Otomatik büyük harf yapma
            entry.bind("<KeyRelease>", lambda e, ent=entry: self.make_uppercase(ent))
            
            self.entries[field] = entry

        # İsim alanına event bağla
        self.entries["İSİM"].bind("<KeyRelease>", self.fill_date_time)

        # Butonlar
        btn_frame = tk.Frame(form_frame, bg="#1a1a1a")
        btn_frame.pack(pady=20, padx=20, fill="x")

        buttons = [
            ("💾 KAYDET", self.save_to_excel, "#00d4ff"),
            ("🔄 GÜNCELLE", self.update_record, "#ff6b35"),
            ("⏰ ÇIKIŞ SAATİ", self.add_exit_time, "#4ecdc4"),
            ("🗑️ SİL", self.delete_record, "#ff5555"),
            ("🧹 TEMİZLE", self.clear_inputs, "#666666")
        ]

        for i, (text, command, color) in enumerate(buttons):
            row = i // 2
            col = i % 2

            btn = tk.Button(btn_frame,
                           text=text,
                           font=("Segoe UI", 9, "bold"),
                           bg=color,
                           fg="#ffffff" if color != "#00d4ff" else "#000000",
                           relief="flat",
                           bd=0,
                           command=command,
                           cursor="hand2")
            btn.grid(row=row, column=col, padx=2, pady=2, sticky="ew")

        btn_frame.grid_columnconfigure(0, weight=1)
        btn_frame.grid_columnconfigure(1, weight=1)

        # Sağ panel - Listbox ve arama (tek panel)
        right_panel = tk.Frame(main_container, bg="#1a1a1a")
        right_panel.pack(side="right", fill="both", expand=True, padx=(5, 0))

        # Arama bölümü (üstte)
        search_frame = tk.Frame(right_panel, bg="#1a1a1a")
        search_frame.pack(fill="x", padx=10, pady=(10, 5))

        search_title = tk.Label(search_frame,
                               text="🔍 ARAMA",
                               font=("Segoe UI", 14, "bold"),
                               fg="#ffd93d",
                               bg="#1a1a1a")
        search_title.pack(pady=(0, 10))

        # Arama kutuları yan yana
        search_inputs = tk.Frame(search_frame, bg="#1a1a1a")
        search_inputs.pack(fill="x", pady=5)

        # Plaka arama (sol)
        plate_frame = tk.Frame(search_inputs, bg="#1a1a1a")
        plate_frame.pack(side="left", fill="x", expand=True, padx=(0, 5))

        tk.Label(plate_frame, text="PLAKA:", fg="#ffd93d", bg="#1a1a1a",
                font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.search_plate_entry = tk.Entry(plate_frame, bg="#2a2a2a", fg="#ffffff",
                                          relief="flat", bd=0, font=("Segoe UI", 10))
        self.search_plate_entry.pack(fill="x", pady=(2, 0), ipady=3)
        self.search_plate_entry.bind("<KeyRelease>", lambda e: self.make_uppercase(self.search_plate_entry))

        # Ad/Soyad arama (sağ)
        name_frame = tk.Frame(search_inputs, bg="#1a1a1a")
        name_frame.pack(side="right", fill="x", expand=True, padx=(5, 0))

        tk.Label(name_frame, text="İSİM / SOYİSİM:", fg="#ff6b35", bg="#1a1a1a",
                font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.search_name_surname_entry = tk.Entry(name_frame, bg="#2a2a2a", fg="#ffffff",
                                                 relief="flat", bd=0, font=("Segoe UI", 10))
        self.search_name_surname_entry.pack(fill="x", pady=(2, 0), ipady=3)
        self.search_name_surname_entry.bind("<KeyRelease>", lambda e: self.make_uppercase(self.search_name_surname_entry))

        # Arama butonları
        search_buttons = tk.Frame(search_frame, bg="#1a1a1a")
        search_buttons.pack(pady=10)

        search_btn = tk.Button(search_buttons,
                              text="🔍 ARA",
                              bg="#ffd93d",
                              fg="#000000",
                              relief="flat",
                              bd=0,
                              font=("Segoe UI", 10, "bold"),
                              command=self.search_records,
                              cursor="hand2",
                              width=12)
        search_btn.pack(side="left", padx=5)

        clear_search_btn = tk.Button(search_buttons,
                                    text="🧹 TEMİZLE",
                                    bg="#666666",
                                    fg="#ffffff",
                                    relief="flat",
                                    bd=0,
                                    font=("Segoe UI", 10, "bold"),
                                    command=self.clear_search,
                                    cursor="hand2",
                                    width=12)
        clear_search_btn.pack(side="left", padx=5)

        # Ziyaretçi listesi (arama bölümünün altında, boydan boya)
        list_container = tk.Frame(right_panel, bg="#1a1a1a")
        list_container.pack(fill="both", expand=True, padx=10, pady=5)

        # Ziyaretçi listesi başlığı
        list_title = tk.Label(list_container,
                             text="📋 ZİYARETÇİ KAYITLARI",
                             font=("Segoe UI", 14, "bold"),
                             fg="#ffd93d",
                             bg="#1a1a1a")
        list_title.pack(pady=(5, 5))

        # Listbox başlıkları frame (genişletildi)
        headers_frame = tk.Frame(list_container, bg="#1a1a1a")
        headers_frame.pack(fill="x", pady=(0, 5))

        # Başlıkların metin listesi
        header_texts = ["D", "İSİM", "SOYİSİM", "FİRMA", "PLAKA", "GELİŞ NEDENİ", 
                        "KİME GELDİ", "GİRİŞ", "ÇIKIŞ", "TARİH", "KAYIT YAPAN P.", "AÇIKLAMA"]

        header_container = tk.Frame(headers_frame, bg="#2a2a2a")
        header_container.pack(fill="x")

        for text in header_texts:
            colors = {
                "D": "#00ff00",
                "İSİM": "#ff6b35",
                "SOYİSİM": "#ff6b35",
                "FİRMA": "#4ecdc4",
                "PLAKA": "#ffd93d",
                "GELİŞ NEDENİ": "#6c5ce7",
                "KİME GELDİ": "#a29bfe",
                "GİRİŞ": "#00b894",
                "ÇIKIŞ": "#e17055",
                "TARİH": "#fdcb6e",
                "KAYIT YAPAN P.": "#fd79a8",
                "AÇIKLAMA": "#74b9ff"
            }
            label = tk.Label(header_container,
                           text=text,
                           font=("Segoe UI", 10, "bold"), 
                           fg=colors.get(text, "#ffffff"),
                           bg="#2a2a2a",
                           width=self.header_widths[text],  
                           anchor="w") 
            label.pack(side="left", padx=0) 

        # Listbox ve scrollbar frame (boydan boya)
        listbox_wrapper_frame = tk.Frame(list_container, bg="#1a1a1a")
        listbox_wrapper_frame.pack(fill="both", expand=True, pady=5)

        # Listbox (boydan boya, daha detaylı)
        self.visitor_listbox = tk.Listbox(listbox_wrapper_frame,
                                         bg="#2a2a2a",
                                         fg="#ffffff",
                                         selectbackground="#00d4ff",
                                         selectforeground="#000000",
                                         font=("Courier New", 10), 
                                         relief="flat",
                                         bd=0,
                                         exportselection=False) # Seçimi korumak için
        
        # Dikey scrollbar
        listbox_v_scrollbar = tk.Scrollbar(listbox_wrapper_frame, orient="vertical", command=self.visitor_listbox.yview)
        self.visitor_listbox.configure(yscrollcommand=listbox_v_scrollbar.set)
        
        # Yatay scrollbar
        listbox_h_scrollbar = tk.Scrollbar(listbox_wrapper_frame, orient="horizontal", command=self.visitor_listbox.xview)
        self.visitor_listbox.configure(xscrollcommand=listbox_h_scrollbar.set)

        self.visitor_listbox.pack(side="left", fill="both", expand=True)
        listbox_v_scrollbar.pack(side="right", fill="y")
        listbox_h_scrollbar.pack(side="bottom", fill="x") 

        # Listbox seçim eventi
        self.visitor_listbox.bind("<<ListboxSelect>>", self.on_listbox_select)

        # Alt panel - Menü butonları
        bottom_frame = tk.Frame(self.root, bg="#0a0a0a")
        bottom_frame.pack(fill="x", pady=5)

        menu_buttons = []
        if self.current_user_type == "admin":
            menu_buttons = [
                ("🔙 GERİ", self.create_admin_menu, "#666666"),
                ("🛡️ ADMİN MENÜ", self.create_admin_menu, "#ff6b35"),
                ("📊 EXCEL YÜK", self.load_excel_file, "#4ecdc4"),
                ("💾 EXCEL KAYDET", self.save_all_to_excel, "#00d4ff"),
                ("🚪 ÇIKIŞ", self.logout, "#ff5555")
            ]
        else:
            menu_buttons = [
                ("🔙 GERİ", self.create_main_screen, "#666666"),
                ("📊 EXCEL YÜK", self.load_excel_file, "#4ecdc4"),
                ("💾 EXCEL KAYDET", self.save_all_to_excel, "#00d4ff"),
                ("🚪 ÇIKIŞ", self.logout, "#ff5555")
            ]

        for text, command, color in menu_buttons:
            btn = tk.Button(bottom_frame,
                           text=text,
                           font=("Segoe UI", 10, "bold"),
                           bg=color,
                           fg="#ffffff" if color != "#00d4ff" else "#000000",
                           relief="flat",
                           bd=0,
                           command=command,
                           cursor="hand2")
            btn.pack(side="left", padx=3, fill="x", expand=True)

        # Excel'den veri yükle ve listbox'ı güncelle
        self.load_data_from_excel()
        self.update_visitor_listbox()
        # Uygulama açıldığında listbox'ı en alta kaydır
        self.scroll_to_bottom()

    def make_uppercase(self, entry_widget):
        """Entry widget'indaki yazıyı büyük harfe çevirir"""
        current_pos = entry_widget.index(tk.INSERT)
        current_text = entry_widget.get()
        upper_text = current_text.upper()
        
        if current_text != upper_text:
            entry_widget.delete(0, tk.END)
            entry_widget.insert(0, upper_text)
            entry_widget.icursor(current_pos)

    def update_visitor_listbox(self):
        """Ziyaretçi listbox'ını günceller - daha detaylı gösterim"""
        if not self.visitor_listbox:
            return
            
        # Mevcut scroll pozisyonunu kaydet
        current_yview = self.visitor_listbox.yview()
        current_xview = self.visitor_listbox.xview()

        self.visitor_listbox.delete(0, tk.END)
        
        # Toplam genişliği hesapla (başlık genişlikleri + her sütun arası 1 boşluk için)
        total_width = sum(self.header_widths.values()) + (len(self.header_widths) - 1) * 1 
        
        for i, row in enumerate(self.all_data):
            # Tüm alanları al ve belirli uzunlukta kes
            # Boş değerler için boş string kullan
            name = str(row[0]) if len(row) > 0 and row[0] else ""
            surname = str(row[1]) if len(row) > 1 and row[1] else ""
            company = str(row[2]) if len(row) > 2 and row[2] else ""
            plate = str(row[3]) if len(row) > 3 and row[3] else ""
            reason = str(row[4]) if len(row) > 4 and row[4] else ""
            visitor_to = str(row[5]) if len(row) > 5 and row[5] else ""
            entry_time = str(row[6]) if len(row) > 6 and row[6] else ""
            exit_time = str(row[7]) if len(row) > 7 and row[7] else ""
            date = str(row[8]) if len(row) > 8 and row[8] else ""
            reg_person = str(row[9]) if len(row) > 9 and row[9] else "" 
            desc = str(row[10]) if len(row) > 10 and row[10] else "" 
            
            # Durum kontrolü
            status = "🔴" if exit_time else "🟢"
            
            # Formatlanmış görüntüleme (tüm bilgiler dahil) - her sütun kendi genişliğine göre hizalandı
            display_text = (
                f"{status:<{self.header_widths['D']}} "
                f"{name[:self.header_widths['İSİM']]:<{self.header_widths['İSİM']}} "
                f"{surname[:self.header_widths['SOYİSİM']]:<{self.header_widths['SOYİSİM']}} "
                f"{company[:self.header_widths['FİRMA']]:<{self.header_widths['FİRMA']}} "
                f"{plate[:self.header_widths['PLAKA']]:<{self.header_widths['PLAKA']}} "
                f"{reason[:self.header_widths['GELİŞ NEDENİ']]:<{self.header_widths['GELİŞ NEDENİ']}} "
                f"{visitor_to[:self.header_widths['KİME GELDİ']]:<{self.header_widths['KİME GELDİ']}} "
                f"{entry_time[:self.header_widths['GİRİŞ']]:<{self.header_widths['GİRİŞ']}} "
                f"{exit_time[:self.header_widths['ÇIKIŞ']]:<{self.header_widths['ÇIKIŞ']}} "
                f"{date[:self.header_widths['TARİH']]:<{self.header_widths['TARİH']}} "
                f"{reg_person[:self.header_widths['KAYIT YAPAN P.']]:<{self.header_widths['KAYIT YAPAN P.']}} "
                f"{desc[:self.header_widths['AÇIKLAMA']]:<{self.header_widths['AÇIKLAMA']}}"
            )
            self.visitor_listbox.insert(tk.END, display_text)
        
        # Listbox'ın total genişliğini ayarlayarak içeriğe sığmasını sağla
        self.visitor_listbox.config(width=total_width)

        # Önceki scroll pozisyonunu geri yükle
        self.visitor_listbox.yview_moveto(current_yview[0])
        self.visitor_listbox.xview_moveto(current_xview[0])


    def on_listbox_select(self, event):
        """Listbox'ta seçim yapıldığında çalışır"""
        selection = self.visitor_listbox.curselection()
        if not selection: 
            return
            
        index = selection[0]
        if index < len(self.all_data):
            row = self.all_data[index]
            
            # Form alanlarını doldur
            fields = ["İSİM", "SOYİSİM", "FİRMA", "PLAKA", "GELİŞ NEDENİ",
                     "KİME GELDİ", "GİRİŞ SAATİ", "ÇIKIŞ SAATİ", "TARİH",
                     "KAYIT YAPAN P.", "AÇIKLAMA"]

            for i, field in enumerate(fields):
                if i < len(row) and field in self.entries:
                    self.entries[field].delete(0, tk.END)
                    self.entries[field].insert(0, str(row[i]) if row[i] is not None else "")
                
    def fill_date_time(self, event=None):
        """İsim girildiğinde tarih, saat ve personel adını otomatik doldurur"""
        if self.entries["İSİM"].get().strip():
            now = datetime.now()
            if not self.entries["TARİH"].get():
                self.entries["TARİH"].delete(0, tk.END)
                self.entries["TARİH"].insert(0, now.strftime("%d.%m.%Y"))
            if not self.entries["GİRİŞ SAATİ"].get():
                self.entries["GİRİŞ SAATİ"].delete(0, tk.END)
                self.entries["GİRİŞ SAATİ"].insert(0, now.strftime("%H:%M"))
            if not self.entries["KAYIT YAPAN P."].get() and self.current_user_name:
                self.entries["KAYIT YAPAN P."].delete(0, tk.END)
                self.entries["KAYIT YAPAN P."].insert(0, self.current_user_name.upper())
        
        # Büyük harf yap
        self.make_uppercase(self.entries["İSİM"])

    def clear_inputs(self):
        """Tüm giriş alanlarını temizler"""
        for entry in self.entries.values():
            entry.delete(0, tk.END)

    def process_row_for_excel(self, row_values):
        """Bir satırdaki verileri Excel'e yazmak için uygun formata getirir."""
        processed_row = [str(cell) if cell is not None else "" for cell in row_values]
        # Listenin her zaman tüm sütunları içerecek kadar uzun olduğundan emin ol (11 sütun)
        while len(processed_row) < 11: 
            processed_row.append("")
        return processed_row

    def save_to_excel(self):
        """Veriyi Excel'e kaydeder"""
        required_fields = ["İSİM", "SOYİSİM", "FİRMA", "PLAKA"]
        for field in required_fields:
            if not self.entries[field].get().strip():
                messagebox.showwarning("Uyarı", f"Lütfen {field} alanını doldurunuz!")
                self.entries[field].focus()
                return

        data = []
        for field in ["İSİM", "SOYİSİM", "FİRMA", "PLAKA", "GELİŞ NEDENİ",
                     "KİME GELDİ", "GİRİŞ SAATİ", "ÇIKIŞ SAATİ", "TARİH",
                     "KAYIT YAPAN P.", "AÇIKLAMA"]: 
            val = self.entries[field].get().strip().upper()
            data.append(val if val else "")

        try:
            excel_file_path = "ziyaretci_kayitlari.xlsx"
            if os.path.exists(excel_file_path):
                wb = load_workbook(excel_file_path)
                ws = wb.active
            else:
                wb = Workbook()
                ws = wb.active
                headers = ["İSİM", "SOYİSİM", "FİRMA", "PLAKA", "GELİŞ NEDENİ",
                          "KİME GELDİ", "GİRİŞ SAATİ", "ÇIKIŞ SAATİ", "TARİH",
                          "KAYIT YAPAN P.", "AÇIKLAMA"]
                ws.append(headers)

            ws.append(self.process_row_for_excel(data)) # Veriyi işleyerek ekle
            wb.save(excel_file_path)
            messagebox.showinfo("Başarılı", "Kayıt başarıyla kaydedildi!")
            self.clear_inputs()
            self.load_data_from_excel()
            self.update_inside_visitors_count()
            self.scroll_to_bottom() # Sadece kayıt eklerken en alta kaydır
            self.clear_search() # Arama yapıldıysa temizle

        except Exception as e:
            messagebox.showerror("Hata", f"Kayıt sırasında hata oluştu: {str(e)}")

    def load_data_for_count(self):
        """Excel dosyasından sadece sayı saymak için verileri yükler."""
        try:
            if os.path.exists("ziyaretci_kayitlari.xlsx"):
                wb = load_workbook("ziyaretci_kayitlari.xlsx")
                ws = wb.active
                self.all_data = []
                for row in ws.iter_rows(min_row=2, values_only=True):
                    if any(cell for cell in row):
                        self.all_data.append(self.process_row_for_excel(row)) # Veriyi işleyerek ekle
        except:
            self.all_data = []

    def load_data_from_excel(self):
        """Excel dosyasından verileri yükler"""
        try:
            if os.path.exists("ziyaretci_kayitlari.xlsx"):
                wb = load_workbook("ziyaretci_kayitlari.xlsx")
                ws = wb.active

                self.all_data = []
                for row in ws.iter_rows(min_row=2, values_only=True):
                    if any(cell for cell in row):
                        self.all_data.append(self.process_row_for_excel(row)) # Veriyi işleyerek ekle

                # Listbox'ı güncelle
                self.update_visitor_listbox()

        except Exception as e:
            messagebox.showerror("Hata", f"Excel dosyası yüklenirken hata oluştu: {str(e)}")

    def scroll_to_bottom(self):
        """Listbox'ı en alta kaydırır"""
        if self.visitor_listbox.size() > 0:
            self.visitor_listbox.selection_clear(0, tk.END)
            self.visitor_listbox.selection_set(tk.END)
            self.visitor_listbox.see(tk.END)

    def update_inside_visitors_count(self):
        """İçerideki ziyaretçi sayısını günceller"""
        count = 0
        for row in self.all_data:
            if len(row) > 7:
                exit_time = str(row[7]).strip()
                if not exit_time or exit_time == "":
                    count += 1
        self.inside_visitors_count = count

        if self.count_label_main and self.count_label_main.winfo_exists():
            self.count_label_main.config(text=f"İçerideki Ziyaretçi Sayısı: {self.inside_visitors_count}")
        if self.count_label_visitor and self.count_label_visitor.winfo_exists():
            self.count_label_visitor.config(text=f"İçerideki Ziyaretçi Sayısı: {self.inside_visitors_count}")

    def update_record(self):
        """Seçili kaydı günceller"""
        selection = self.visitor_listbox.curselection()
        if not selection:
            messagebox.showwarning("Uyarı", "Lütfen güncellenecek kaydı seçiniz!")
            return

        new_values = []
        for field in ["İSİM", "SOYİSİM", "FİRMA", "PLAKA", "GELİŞ NEDENİ",
                     "KİME GELDİ", "GİRİŞ SAATİ", "ÇIKIŞ SAATİ", "TARİH",
                     "KAYIT YAPAN P.", "AÇIKLAMA"]: 
            val = self.entries[field].get().strip().upper()
            new_values.append(val if val else "")

        item_index = selection[0]
        # self.clear_inputs() # Güncelleme sonrası temizleme isteğe bağlı. Seçim korunurken bu kaldırılabilir.

        if 0 <= item_index < len(self.all_data):
            self.all_data[item_index] = self.process_row_for_excel(new_values) # Veriyi işleyerek güncelle

        self.update_excel()
        self.update_inside_visitors_count()
        self.update_visitor_listbox() # Güncelledikten sonra pozisyonu koruyacak
        self.visitor_listbox.selection_set(item_index) # Güncelleme sonrası seçimi tekrar ayarla
        messagebox.showinfo("Başarılı", "Kayıt başarıyla güncellendi!")

    def add_exit_time(self):
        """Seçili kayda çıkış saati ekler"""
        selection = self.visitor_listbox.curselection()
        if not selection:
            messagebox.showwarning("Uyarı", "Lütfen çıkış saati eklenecek kaydı seçiniz!")
            return

        item_index = selection[0]

        values_from_all_data = list(self.all_data[item_index])

        if len(values_from_all_data) > 7 and str(values_from_all_data[7]).strip() != "":
            messagebox.showinfo("Bilgi", "Bu kaydın çıkış saati zaten eklenmiş.")
            return

        # Listede yeterli eleman yoksa boş stringlerle doldur
        # Bu kısım process_row_for_excel ile zaten sağlanıyor, ancak güvenlik için bırakılabilir.
        # while len(values_from_all_data) < 11: 
        #     values_from_all_data.append("")
            
        values_from_all_data[7] = datetime.now().strftime("%H:%M")

        # self.clear_inputs() # Çıkış saati ekledikten sonra girişleri temizleme isteğe bağlı

        self.all_data[item_index] = self.process_row_for_excel(values_from_all_data) # Veriyi işleyerek güncelle

        self.update_excel()
        self.update_inside_visitors_count()
        self.update_visitor_listbox() # Güncelledikten sonra pozisyonu koruyacak
        self.visitor_listbox.selection_set(item_index) # Güncelleme sonrası seçimi tekrar ayarla
        messagebox.showinfo("Başarılı", "Çıkış saati başarıyla eklendi!")

    def update_excel(self):
        """Excel dosyasını all_data'daki verilerle günceller"""
        try:
            wb = Workbook()
            ws = wb.active

            headers = ["İSİM", "SOYİSİM", "FİRMA", "PLAKA", "GELİŞ NEDENİ",
                      "KİME GELDİ", "GİRİŞ SAATİ", "ÇIKIŞ SAATİ", "TARİH",
                      "KAYIT YAPAN P.", "AÇIKLAMA"]
            ws.append(headers)

            for row_values in self.all_data: 
                ws.append(self.process_row_for_excel(row_values)) # Veriyi işleyerek ekle

            wb.save("ziyaretci_kayitlari.xlsx")

        except Exception as e:
            messagebox.showerror("Hata", f"Excel güncelleme hatası: {str(e)}")

    def delete_record(self):
        """Seçili kaydı siler"""
        selection = self.visitor_listbox.curselection()
        if not selection:
            messagebox.showwarning("Uyarı", "Lütfen silinecek kaydı seçiniz!")
            return

        if messagebox.askyesno("Onay", "Seçili kaydı silmek istediğinizden emin misiniz?"):
            item_index = selection[0]

            if 0 <= item_index < len(self.all_data):
                del self.all_data[item_index]

            self.update_excel()
            self.update_inside_visitors_count()
            self.update_visitor_listbox() # Sildikten sonra pozisyonu koruyacak
            self.clear_inputs()
            messagebox.showinfo("Başarılı", "Kayıt başarıyla silindi!")

    def search_records(self):
        """Kayıtlarda arama yapar"""
        plate_search = self.search_plate_entry.get().strip().upper()
        name_search = self.search_name_surname_entry.get().strip().upper()

        if not plate_search and not name_search:
            messagebox.showwarning("Uyarı", "Lütfen arama kriteri giriniz!")
            self.load_data_from_excel() # Arama kriteri yoksa tüm verileri geri yükle
            return

        # Geçici filtrelenmiş veri listesi
        filtered_data = []
        found_count = 0
        
        for row in self.all_data:
            match_found = False
            processed_row = self.process_row_for_excel(row) # Arama yaparken de tutarlı format kullanalım

            if plate_search and processed_row[3]: # PLAKA sütunu (indeks 3)
                if plate_search in processed_row[3].upper():
                    match_found = True

            if name_search: # İSİM (indeks 0) ve SOYİSİM (indeks 1)
                full_name = f"{processed_row[0]} {processed_row[1]}".upper()
                if name_search in full_name:
                    match_found = True

            if match_found:
                filtered_data.append(processed_row) # İşlenmiş satırı ekle
                found_count += 1

        # Listbox'ı filtrelenmiş verilerle güncelle
        self.visitor_listbox.delete(0, tk.END)

        for i, row in enumerate(filtered_data):
            # Tüm alanları al ve belirli uzunlukta kes
            name = str(row[0]) if len(row) > 0 and row[0] else ""
            surname = str(row[1]) if len(row) > 1 and row[1] else ""
            company = str(row[2]) if len(row) > 2 and row[2] else ""
            plate = str(row[3]) if len(row) > 3 and row[3] else ""
            reason = str(row[4]) if len(row) > 4 and row[4] else ""
            visitor_to = str(row[5]) if len(row) > 5 and row[5] else ""
            entry_time = str(row[6]) if len(row) > 6 and row[6] else ""
            exit_time = str(row[7]) if len(row) > 7 and row[7] else ""
            date = str(row[8]) if len(row) > 8 and row[8] else ""
            reg_person = str(row[9]) if len(row) > 9 and row[9] else ""
            desc = str(row[10]) if len(row) > 10 and row[10] else ""
            
            status = "🔴" if exit_time else "🟢"
            
            display_text = (
                f"{status:<{self.header_widths['D']}} "
                f"{name[:self.header_widths['İSİM']]:<{self.header_widths['İSİM']}} "
                f"{surname[:self.header_widths['SOYİSİM']]:<{self.header_widths['SOYİSİM']}} "
                f"{company[:self.header_widths['FİRMA']]:<{self.header_widths['FİRMA']}} "
                f"{plate[:self.header_widths['PLAKA']]:<{self.header_widths['PLAKA']}} "
                f"{reason[:self.header_widths['GELİŞ NEDENİ']]:<{self.header_widths['GELİŞ NEDENİ']}} "
                f"{visitor_to[:self.header_widths['KİME GELDİ']]:<{self.header_widths['KİME GELDİ']}} "
                f"{entry_time[:self.header_widths['GİRİŞ']]:<{self.header_widths['GİRİŞ']}} "
                f"{exit_time[:self.header_widths['ÇIKIŞ']]:<{self.header_widths['ÇIKIŞ']}} "
                f"{date[:self.header_widths['TARİH']]:<{self.header_widths['TARİH']}} "
                f"{reg_person[:self.header_widths['KAYIT YAPAN P.']]:<{self.header_widths['KAYIT YAPAN P.']}} "
                f"{desc[:self.header_widths['AÇIKLAMA']]:<{self.header_widths['AÇIKLAMA']}}"
            )
            self.visitor_listbox.insert(tk.END, display_text)
        
        # Filtrelenmiş veri Listbox'ın total genişliğini ayarlayarak içeriğe sığmasını sağla
        total_width = sum(self.header_widths.values()) + (len(self.header_widths) - 1) * 1 
        self.visitor_listbox.config(width=total_width)


        if found_count == 0:
            messagebox.showinfo("Sonuç", "Arama kriterlerinize uygun kayıt bulunamadı!")
        else:
            messagebox.showinfo("Sonuç", f"{found_count} kayıt bulundu!")

    def clear_search(self):
        """Arama alanlarını temizler ve tüm kayıtları gösterir"""
        self.search_plate_entry.delete(0, tk.END)
        self.search_name_surname_entry.delete(0, tk.END)
        self.load_data_from_excel()
        self.scroll_to_bottom() # Aramayı temizleyince en alta kaydır

    def load_excel_file(self):
        """Mevcut Excel dosyasını yeniden yükler"""
        self.load_data_from_excel()
        self.update_inside_visitors_count()
        self.scroll_to_bottom() # Yükledikten sonra en alta kaydır
        messagebox.showinfo("Başarılı", "Excel dosyası yeniden yüklendi!")

    def save_all_to_excel(self):
        """Tüm verileri Excel'e kaydeder"""
        try:
            self.update_excel()
            messagebox.showinfo("Başarılı", "Tüm veriler Excel'e kaydedildi!")
        except Exception as e:
            messagebox.showerror("Hata", f"Excel kaydetme hatası: {str(e)}")

    def logout(self):
        """Çıkış yapar ve ana ekrana döner"""
        self.current_user_type = None
        self.current_user_name = None
        self.create_main_screen()

    def clear_window(self):
        """Pencereyi temizler"""
        for widget in self.root.winfo_children():
            widget.destroy()

    def check_for_updates(self):
        """Güncelleme kontrolü yapar"""
        try:
            # GitHub API endpoint'i doğru repo ile güncellendi
            response = requests.get("https://api.github.com/repos/yamann0101/sur-bey-updates/releases/latest", timeout=10)
            response.raise_for_status()  # HTTP hatalarını (örneğin 404) yakalamak için

            latest_release = response.json()
            latest_version = latest_release["tag_name"]

            if latest_version != CURRENT_VERSION:
                update_zip_url = None
                for asset in latest_release["assets"]:
                    # Zip dosyasını bulmak için kontrol
                    if asset["name"].endswith(".zip"):
                        update_zip_url = asset["browser_download_url"]
                        break

                if update_zip_url:
                    message = f"Yeni güncelleme mevcut!\n\nMevcut Sürüm: {CURRENT_VERSION}\nYeni Sürüm: {latest_version}\n\nGüncellemeyi indirip uygulamak istiyor musunuz?\n(Uygulama kendini kapatıp güncellenecektir.)"
                    if messagebox.askyesno("Güncelleme Mevcut", message):
                        self.download_and_apply_update(update_zip_url)
                    else:
                        messagebox.showinfo("Bilgi", "Güncelleme iptal edildi.")
                else:
                    messagebox.showinfo("Güncelleme Yok", "Güncelleme için zip dosyası bulunamadı. Lütfen GitHub Releases bölümünü kontrol edin.")
            else:
                messagebox.showinfo("Güncelleme Yok", "Uygulamanız güncel!")
        except requests.exceptions.RequestException as e:
            messagebox.showerror("Güncelleme Hatası", f"Güncelleme sunucusuna bağlanılamadı veya bir HTTP hatası oluştu:\n{e}\nLütfen internet bağlantınızı ve GitHub deposundaki 'Releases' bölümünü kontrol edin.")
        except Exception as e:
            messagebox.showerror("Güncelleme Hatası", f"Güncelleme kontrol edilirken bir hata oluştu:\n{e}")

    def download_and_apply_update(self, update_zip_url):
        """Güncelleme dosyasını indirir ve uygular."""
        update_file_name = "update.zip"
        current_script_name = os.path.basename(sys.argv[0])
        backup_script_name = current_script_name + ".bak"

        try:
            messagebox.showinfo("Bilgi", "Güncelleme indiriliyor, lütfen bekleyiniz...")
            self.root.update_idletasks()

            with requests.get(update_zip_url, stream=True) as r:
                r.raise_for_status()
                with open(update_file_name, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)

            self.root.destroy() # Uygulamayı kapat

            # Güncelleyici script'i oluştur ve başlat
            updater_script_content = f"""
import os
import sys
import zipfile
import shutil
import time

APP_NAME = "{current_script_name}"
BACKUP_NAME = "{backup_script_name}"
UPDATE_ZIP = "{update_file_name}"
EXCEL_FILE = "ziyaretci_kayitlari.xlsx"
USERS_FILE = "users.json"

print("Güncelleyici başlatılıyor...")
time.sleep(1) # Küçük bir gecikme

try:
    # Mevcut uygulamayı yedekle
    if os.path.exists(APP_NAME):
        print(f"Eski uygulamayı yedekliyor: {{APP_NAME}} -> {{BACKUP_NAME}}")
        shutil.copy2(APP_NAME, BACKUP_NAME)

    print(f"Güncelleme {{UPDATE_ZIP}} dosyasını açıyor...")
    with zipfile.ZipFile(UPDATE_ZIP, 'r') as zip_ref:
        for member in zip_ref.namelist():
            # Veri dosyalarını atla
            if member == EXCEL_FILE or member == USERS_FILE:
                print(f"  {{member}} atlanıyor (veri dosyası).")
                continue

            # Klasör oluştur
            if member.endswith('/'):
                if not os.path.exists(member):
                    os.makedirs(member)
                continue

            # Dosyayı çıkart (ana uygulama dosyası ise üzerine yaz)
            source = zip_ref.open(member)
            target_path = os.path.join(os.getcwd(), member)
            with open(target_path, "wb") as target:
                shutil.copyfileobj(source, target)
            print(f"  Güncellendi: {{member}}")

    print("Güncelleme tamamlandı.")

    # Temizlik
    if os.path.exists(UPDATE_ZIP):
        os.remove(UPDATE_ZIP)
        print(f"{{UPDATE_ZIP}} temizlendi.")
    if os.path.exists(BACKUP_NAME):
        os.remove(BACKUP_NAME)
        print(f"{{BACKUP_NAME}} temizlendi.")

    print("Uygulama yeniden başlatılıyor...")
    # Yeni uygulamayı başlat
    os.execl(sys.executable, sys.executable, APP_NAME)

except Exception as e:
    with open("update_error.log", "w", encoding="utf-8") as log_f: # encoding ekledik
        log_f.write(f"Güncelleme sırasında hata oluştu: {{e}}\\n")
        log_f.write(f"Hata detayı:\\n{{sys.exc_info()}}\\n")
    print(f"Güncelleme sırasında hata oluştu: {{e}}")
    print("Hata log dosyasına kaydedildi: update_error.log")
    input("Devam etmek için Enter'a basın...")
"""

            # Güncelleyici script'ini dosyaya yaz
            with open("updater.py", "w", encoding="utf-8") as f:
                f.write(updater_script_content)

            # Güncelleyici script'ini başlat ve mevcut uygulamayı kapat
            os.execl(sys.executable, sys.executable, "updater.py")

        except Exception as e:
            messagebox.showerror("Güncelleme Hatası", f"Güncelleme sırasında hata oluştu:\n{e}")


    def run(self):
        """Uygulamayı başlatır"""
        self.root.mainloop()

if __name__ == "__main__":
    app = VisitorApp()
    app.run()
